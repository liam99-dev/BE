const path = require("node:path");
const fastify =  require('fastify')({ logger: true });
let { contacts } = require("./db");
// const db = require('./db');

fastify.register(require("@fastify/mongodb"), {
  forceClose: true,
  url: "mongodb://localhost:27017/students",
})

fastify.register(require('@fastify/view'),{
  engine: {
    pug: require('pug'),
  },
  propertyName: "render",
  root: './view'
});

fastify.register(require("@fastify/static"), {
  root: path.join(__dirname, "static"),
  prefix: "/static"
})

fastify.get('/contacts', async function (req, rep) {
  let p = Number(req.query.p) || 1;
  if (p <= 0 ) p = 1;
  let n = Number(req.query.n) || 5;
  if (n <= 0 ) n = 5;

  const gender = req.query.gender || '';
  const filter = {}
  if (gender === 'male' || gender === 'female'){
    // filter = {... filter, gender: gender}
    filter.gender = gender;
  }

  let minAge = Number(req.query.minAge) || 10;
  if (minAge <10) minAge = 10;


  let maxAge = Number(req.query.maxAge) || 100;
  if (maxAge < minAge ) maxAge = minAge;

  filter.$and = [
          { age: {$gte: minAge} },
          { age: {$lte: maxAge} }
  ];

  const maxPage = Math.ceil((await this.mongo.db.collection("users").estimatedDocumentCount())/n);
  if (p>maxPage) p = maxPage;

  const contacts = await this.mongo.db.collection("users").find({}).skip((p-1)*n).limit(n).toArray();
  rep.render("contacts", { contactList: contacts, p, n, maxPage, gender});
  return rep;

  // let genderFilter = req.query.gender || 'all';
  // const gender = req.query.gender || ''; 
  // // let result = contacts;

  // let contactList = contacts;

  // if (gender === 'male' || gender === 'female'){
  //   result = contactList.filter(c => c.gender === genderFilter);
  // }
  // else{
  //   genderFilter = '';
  // }

  // const name = req.query.name || '';
  // if (req.query.name) {
  //   contactList = contactList.filter(c => c.name.toLowerCase().startsWith(req.query.name.toLowerCase()));
  // }


  // let p = Number(req.query.p) || 1;
  // p = p > 0 ? p : 1;

  
  // const n = Number(req.query.n) || 5;
  // const maxPage = Math.ceil(contactList.length/n);
  // p = p > maxPage ? maxPage : p;


  // // rep.render("contacts",{contactList: db.contacts});
  // rep.render("contacts", {
  //   contactList: contactList.slice((p - 1) * n, p * n), p , n, genderFilter, name});

});


fastify.get("/delete/:id", async function (req, rep) {
  const result = await this.mongo.db.collection("users").deleteOne({_id: new this.mongo.ObjectId(req.params.id)})
  return rep.send(result);

  // contacts = contacts.filter(c => c.id != req.params.id);
  // rep.redirect("/contacts");
})


// fastify.get('/sum/:a/:b',function(req,rep){
//   const a = Number(req.params.a);
//   const b = Number(req.params.b);
//   const sum = a + b;
//   rep.render('home',{
//     a: a,
//     b: b,
//     sum: sum
//   })
// })

// fastify.get('/sum/:a/:b', function handler (request, reply) {
//   reply.send({ 
//       method: request.method,
//       url: request.url,
//       query: request.query,
//       params: request.params,
//   })
// });

fastify.listen({ port: 3001 }, (err) => {
    if (err) {
      fastify.log.error(err)
      process.exit(1)
    }
  });